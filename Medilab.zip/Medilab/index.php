






<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Index - Medilab Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">

  

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Medilab
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <header id="header" class="header sticky-top">

    <div class="topbar d-flex align-items-center">
      <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center">
          <i class=" bi-phone d-flex align-items-center ms-4"><span>+ 965 22220359</span></i>
          <i class="bi bi-phone d-flex align-items-center ms-4"><span>+ 965 65557393</span></i>
        </div>
        <div class="social-links d-none d-md-flex align-items-center">
          <a href="https://www.snapchat.com/add/drhossam.hamdy?share_id=a-bfCshZQa6UHVSbSSdO2A&locale=en_KW" class="snapchat"><i class="bi bi-snapchat"></i></a>
          <a href="https://www.facebook.com/share/1DNVy7dBc7/?mibextid=JRoKGi" class="facebook"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com/drhossam.hamdy.clinic/profilecard/?igsh=ZDltY3Y4cW1ic2Fn" class="instagram"><i class="bi bi-instagram"></i></a>
          <a href="https://www.tiktok.com/@hossamhamdan218?_t=ZS-8rrPBmE7CjJ&_r=1" class="tiktok"><i class="bi bi-tiktok"></i></a>
        </div>
      </div>
    </div><!-- End Top Bar -->

    <div class="branding d-flex align-items-center">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="index.html" class="logo d-flex align-items-center me-auto">
          <!-- Uncomment the line below if you also wish to use an image logo -->
          <!-- <img src="assets/img/logo.png" alt=""> -->
           <img src="logo.png" width="130 px" height="550" >
           <h1 class="sitename" style="font-family: 'Dancing Script', cursive;">Enrich</h1>
           
        </a>

        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="#hero" class="active">Home<br></a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
           
            <li><a href="#doctors">Doctors</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="login.php">Login</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>

        <a class="cta-btn d-none d-sm-block" href="#appointment">Make an Appointment</a>

      </div>

    </div>

  </header>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section light-background">

      <img src="banner1.jpeg" alt=""   width="60px" height="150" >

      <div class="container position-relative">

        <div class="welcome position-relative" data-aos="fade-down" data-aos-delay="100" style="text-align:center ;">
          
         
        </div><!-- End Welcome -->

        

         

    </section><!-- /Hero Section -->

    <!-- About Section -->
    <section id="about" class="about section">

      <div class="container">

        <div class="row gy-4 gx-5">

          <div class="col-lg-6 position-relative align-self-start" data-aos="fade-up" data-aos-delay="200">
            <img src="dr.jpeg" class="img-fluid" alt="">
            <img src="about.mp4" class="glightbox pulsating-play-btn">
          </div>

          <div class="col-lg-6 content" data-aos="fade-up" data-aos-delay="100">

            
            <h3>About Us</h3>
            <p>
              Welcome to Dr. Hossam’s Dermatology Clinic, your trusted partner in advanced skin care and dermatological excellence since 2019. Located in the heart of Kuwait, our clinic is dedicated to providing comprehensive skin treatments tailored to your unique needs. We offer a wide range of services, including acne and scar management, anti-aging solutions, laser treatments, and personalized skin care regimens. With cutting-edge technology and a team of highly skilled professionals, we prioritize delivering exceptional results in a comfortable, patient-focused environment. At Dr. Hossam’s Clinic, we are committed to helping you achieve healthy, radiant skin with care and expertise you can trust
            </p>
           
          </div>

        </div>

      </div>

    </section><!-- /About Section -->

    


    <!-- Services Section -->
    <section id="services" class="services section faq section beige-background">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Services</h2>
        
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="service-item  position-relative">
              
                <img src="acne.jpeg"  width="210" height="200">
              
            
              <a href="#" class="stretched-link">
                <h3> Medical Dermatology</h3>
              </a>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="service-item position-relative">
              <img src="laser.jpeg"  width="210" height="200">
              <a href="#" class="stretched-link">
                <h3>Laser</h3>
              </a>
             
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="service-item position-relative">
             
              <img src="onda.jpeg"  width="210" height="200">
              <a href="#" class="stretched-link">
                <h3>Inshape</h3>
              </a>
              
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="service-item position-relative">
              <img src="botox.jfif"  width="210" height="200">
              <a href="#" class="stretched-link">
                <h3>Botox</h3>
              </a>
              
              <a href="#" class="stretched-link"></a>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="service-item position-relative">
              <img src="filler.jpeg"  width="210" height="200">
              <a href="#" class="stretched-link">
                <h3>filler</h3>
              </a>
              
              <a href="#" class="stretched-link"></a>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative">
              <img src="threads.png"  width="210" height="200">
              <a href="#" class="stretched-link">
                <h3>Contour</h3>
              </a>
             
              <a href="#" class="stretched-link"></a>
            </div></div><!-- End Service Item -->




            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
              <div class="service-item position-relative">
                <img src="facial.jpg"  width="210" height="200">
                <a href="#" class="stretched-link">
                  <h3>Facial</h3>
                </a>
                
                <a href="#" class="stretched-link"></a>
              </div>
          </div><!-- End Service Item -->



          
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative">
              <img src="booster.jfif"  width="210" height="200">
              <a href="#" class="stretched-link">
                <h3>Skin Booster</h3>
              </a>
             
              <a href="#" class="stretched-link"></a>
            </div>
        </div><!-- End Service Item -->



        
        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
          <div class="service-item position-relative">
            <img src="fractional.webp"  width="210" height="200">
            <a href="#" class="stretched-link">
              <h3>Fractional Laser</h3>
            </a>
           
            <a href="#" class="stretched-link"></a>
          </div>
      </div><!-- End Service Item -->

        </div>

      </div>

    </section><!-- /Services Section -->

    <!-- Appointment Section -->
    <section id="appointment" class="appointment section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Appointment</h2>
       
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <form action="appointment_handler.php" method="post" role="form" >


        
          <div class="row">
            <div class="col-md-4 form-group">
              <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required="">
            </div>
           
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <input type="tel" class="form-control" name="phone" id="phone" placeholder="Your Phone" required="">
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <input type="datetime-local" name="date" class="form-control datepicker" id="date" placeholder="Appointment Date" required="">
            </div>
          </div>
          <div class="row">
           
            <div class="col-md-4 form-group mt-3">
              <select name="service" id="department" class="form-select" required="">
                <option value="">Select service</option>
                <option value="laser">laser</option>
                <option value="consultant">Meet the dr</option>
                <option value="Facial">Facial</option>
                <option value="Inshape">Inshape</option>
              </select>
            </div>
           
          </div>

          
          <div class="mt-3">
          
            <div class="text-center"><button type="submit"   style="background-color:#C2A267;border-color:#C2A267;">Make an Appointment</button></div>
          </div>
        </form>

      </div>

    </section><!-- /Appointment Section -->

   
               
              

    <!-- Doctors Section -->
    <section id="doctors" class="doctors section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Doctor</h2>
       
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
          
              <img src="drh.jpeg" class="img-fluid" alt="">
              
            </div>
  
            <div class="col-lg-6 content" data-aos="fade-up" data-aos-delay="100">
              <h2> About Doctor Hossam</h2>
              
              <p>
                Dr. Hossam Hamdy is a highly skilled specialist in dermatology, aesthetics, and laser treatments, with extensive expertise in providing advanced skin care solutions. He is a proud member of the Egyptian Society of Dermatology and Aesthetics, as well as the European Academy of Dermatology and Venereology. Dr. Hossam holds a certification from the prestigious National Institute of Laser Sciences and a degree in dermatology from Alexandria University. His dedication to excellence and continuous learning has earned him recognition as a trusted expert in skin health and beauty. With a patient-centered approach and a commitment to using cutting-edge techniques, Dr. Hossam ensures exceptional care and outstanding results for all his patients.
              </p>
              
             
            </div>

          

          

          

        </div>

      </div>

    </section><!-- /Doctors Section -->

    <!-- Faq Section -->
    <section id="faq" class="faq section beige-background">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Frequently Asked Questions</h2>
        
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row justify-content-center">

          <div class="col-lg-10" data-aos="fade-up" data-aos-delay="100">

            <div class="faq-container">

              <div class="faq-item faq-active">
                <h3>Why choose us?</h3>
                <div class="faq-content">
                  <p>At Dr. Hossam Hamdy’s Clinic, we blend years of expertise with state-of-the-art technology to offer exceptional medical and cosmetic dermatology services. Under the leadership of the highly respected Dr. Hossam Hamdy, our dedicated team strives to provide personalized care tailored to each patient’s unique needs. Committed to the highest standards of safety and excellence, we aim to help you achieve healthy, glowing skin with advanced treatments and compassionate care.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

              <div class="faq-item">
                <h3>Who do  i meet with for my consultation or treatment?</h3>
                <div class="faq-content">
                  <p>Your consultation or treatment will be conducted by Dr. Hossam Hamdy himself, ensuring you receive expert care and personalized attention from a highly experienced specialist in dermatology, aesthetics, and laser treatments..</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

              <div class="faq-item">
                <h3>Do you offer installments for the session fees</h3>
                <div class="faq-content">
                  <p>yes,we do</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

              <div class="faq-item">
                <h3>What type of skincare treatments do you offer?</h3>
                <div class="faq-content">
                  <p>We offer a wide range of skincare treatments, including facials, chemical peels, microdermabrasion, laser treatments, and more. Our expert team will work with you to customize a treatment plan that addresses your specific skin concerns and goals..</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

              

            </div>

          </div><!-- End Faq Column-->

        </div>

      </div>

    </section><!-- /Faq Section -->

    <!-- Testimonials Section -->
    <section id="testimonials" class="testimonials section">

      <div class="container">

        <div class="row align-items-center">

         
            <h3 style="text-align: center;  font-family: 'Dancing Script', cursive; font-size: 60px;">"Enrich Your Beauty, Elevate Your Confidence"</h3>
            
          

          
              

               

                
                

                

         

        </div>

      </div>

    </section><!-- /Testimonials Section -->

    <!-- Gallery Section -->
    <section id="gallery" class="gallery section faq section beige-background">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Gallery</h2>
        
      </div><!-- End Section Title -->

      <div class="container-fluid" data-aos="fade-up" data-aos-delay="100">

        <div class="row g-0">

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/img1.jpg" class="glightbox" data-gallery="images-gallery">
                <img src="assets/img/gallery/img1.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div><!-- End Gallery Item -->

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/img2.jpg" class="glightbox" data-gallery="images-gallery">
                <img src="assets/img/gallery/img2.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div><!-- End Gallery Item -->

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/img12.jpg" class="glightbox" data-gallery="images-gallery">
                <img src="assets/img/gallery/img12.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div><!-- End Gallery Item -->

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/img7.jpg" class="glightbox" data-gallery="images-gallery">
                <img src="assets/img/gallery/img7.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div><!-- End Gallery Item -->

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/img6.jpg" class="glightbox" data-gallery="images-gallery">
                <img src="assets/img/gallery/img6.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div><!-- End Gallery Item -->

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/img5.png" class="glightbox" data-gallery="images-gallery">
                <img src="assets/img/gallery/img5.png" alt="" class="img-fluid">
              </a>
            </div>
          </div><!-- End Gallery Item -->

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/img11.jpg" class="glightbox" data-gallery="images-gallery">
                <img src="assets/img/gallery/img11.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div><!-- End Gallery Item -->

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="assets/img/gallery/img10.jpg" class="glightbox" data-gallery="images-gallery">
                <img src="assets/img/gallery/img10.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div><!-- End Gallery Item -->

        </div>

      </div>

    </section><!-- /Gallery Section -->

    <!-- Contact Section -->
    <section id="contact" class="contact section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Contacts & Feedback</h2>
        
      </div><!-- End Section Title -->

      <div class="mb-5" data-aos="fade-up" data-aos-delay="200">
        <iframe style="border:0; width: 100%; height: 270px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3477.251114196872!2d47.977405715034486!3d29.376362482115448!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fcf9c9263a93cf7%3A0xa874b6e0fef1d80!2z2YjYqPCF2YrZhdmF!5e0!3m2!1sen!2skw!4v1701512485968!5m2!1sen!2skw" frameborder="0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div><!-- End Google Maps -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-4">
            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-geo-alt flex-shrink-0"></i>
              <div>
                <h3>Location</h3>
                <a href="https://www.google.com/maps/place/Marina+Medical+Center/@29.3440956,48.0897021,17z/data=!4m6!3m5!1s0x3fcf763b7b7a13eb:0x9ab50eb6df3dcc4d!8m2!3d29.3440956!4d48.0922824!16s%2Fg%2F11g7cv7jgb?entry=ttu&g_ep=EgoyMDI0MTIwMS4xIKXMDSoASAFQAw%3D%3D">99 شارع الخنساء - تقاطع, Hamad Al-Mubarak St, Salmiya, Kuwait</a>
              </div>
            </div><!-- End Info Item -->

            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
              <i class="bi bi-telephone flex-shrink-0"></i>
              <div>
                <h3>Call Us</h3>
                <p>+ 965 22220359</p>
                <p>+ 965 65557393</p>
              </div>
            </div><!-- End Info Item -->

            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="500">
              <i class="bi bi-envelope flex-shrink-0"></i>
              <div>
                <h3>Email Us</h3>
                <p>info@drhossamclinic.com</p>
              </div>
            </div><!-- End Info Item -->

          </div>

          <div class="col-lg-8">
          
            <form action="contact_handler.php" method="post" role="form" >

              <div class="row gy-4">

                <div class="col-md-6">
                  <input type="text" name="name" class="form-control" placeholder="Your Name" required="">
                </div>

                <div class="col-md-6 ">
                  <input type="email" class="form-control" name="email" placeholder="Your Email" required="">
                </div>


                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required=""></textarea>
                </div>

                <div class="col-md-12 text-center">
                  
                  <button type="submit" style="background-color:#C2A267;border-color:#C2A267;" >Send your Feedback</button>
                </div>

              </div>
            </form>
          </div><!-- End Contact Form -->

        </div>

      </div>

    </section><!-- /Contact Section -->

  </main>

  <footer id="footer" class="footer faq section beige">

    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index.html" class="logo d-flex align-items-center">
            <span class="sitename">Enrich Clinic</span>
          </a>
          <div class="footer-contact pt-3">
            <p>Al Khansa Street</p>
            <p>Salmiya 20003, Kuwait</p>
            <p class="mt-3"><strong>Phone:</strong><br><span>+ 965 22220359</span><br><span>+ 965 65557393</span></p>
            <p><strong>Email:</strong> <span>info@drhossamclinic.com</span></p>
          </div>
          <div class="social-links d-flex mt-4">
            <a href=""><i class="bi bi-snapchat"></i></a>
            <a href="https://www.facebook.com/share/1DNVy7dBc7/?mibextid=JRoKGi"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/drhossam.hamdy.clinic/profilecard/?igsh=ZDltY3Y4cW1ic2Fn"><i class="bi bi-instagram"></i></a>
            <a href="https://www.tiktok.com/@hossamhamdan218?_t=ZS-8rrPBmE7CjJ&_r=1"><i class="bi bi-tiktok"></i></a>
          </div>
        </div>

        <div class="col-lg-2 col-md-3 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><a href="#hero">Home</a></li>
            <li><a href="#about">About us</a></li>
            <li><a href="#">Terms of service</a></li>
            <li><a href="#">Privacy policy</a></li>
          </ul>
        </div>

        <div class="col-lg-2 col-md-3 footer-links">
          <h4>Our Services</h4>
          <ul>
            <li><a href="#services">Services</a></li>
            <li><a href="#appointment">Book Your Appointment</a></li>
          
          </ul>
        </div>

        

      </div>
    </div>

    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Enrich</strong> <span>All Rights Reserved</span></p>
      
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>