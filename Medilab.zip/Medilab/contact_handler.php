<?php  
session_start();

$name = $_POST["name"];
$email = $_POST["email"];
$message = $_POST["message"];

$server = "localhost";
$user = "root";
$pw = "";
$db = "clinic";

$conn = new mysqli($server, $user, $pw, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$txt = "INSERT INTO feedback(name, email,message) VALUES ('$name', '$email', '$message')";

if ($conn->query($txt) === TRUE) {
    // Trigger the custom alert
    echo "
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('custom-alert');
            modal.style.display = 'block';
        });

        function redirectToIndex() {
            window.location.href = 'index.php';
        }
    </script>
    <div id='custom-alert' style='display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999;'>
        <div style='margin:15% auto; padding:20px; background:white; width:300px; text-align:center; border-radius:5px;'>
            <h2>Feedback Submitted</h2>
            <p>Your feedback has been sent. Thank you!</p>
            <button onclick='redirectToIndex()' style='padding:10px 20px;background-color:#C2A267;border-color:#C2A267; color:white; border:none; border-radius:5px;'>OK</button>
        </div>
    </div>";
} else {
    echo "Error: " . $txt . "<br>" . $conn->error;
}

$conn->close();
?>
