<?php  
session_start();
$email=$_POST["email"];
$pwd=$_POST["pwd"];

$con=mysqli_connect("localhost" , "root","") or die ("Error: can't connect ");
$db=mysqli_select_db($con ,"clinic") or die ("Error: can't connect to db");

$txt="select * from clients where email='$email' and pwd='$pwd'";

$result=mysqli_query($con , $txt);
$count=mysqli_num_rows($result);

if ($count == 1) {
    header('Location:index.php');
   
} else {
    echo "invalid";
}
?>