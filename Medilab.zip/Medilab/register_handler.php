<?php  

session_start();
$firstName=$_POST["firstName"];
$lastName=$_POST["lastName"];
$email=$_POST["email"];
$pwd=$_POST["pwd"];
$server="localhost";
$user="root";
$pw="";
$db="clinic";
$conn=new mysqli($server,$user,$pw ,$db);


$txt="INSERT into clients(firstName,lastName,email,pwd) values('$firstName','$lastName' ,'$email' ,'$pwd') ";

if($conn->query($txt)){

    header('location:login.php');

}
else{
    echo"error";
}

?>