<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Enrich Clinic - Excellence in Care</title>
  <meta name="description" content="Enrich Clinic offers professional medical services tailored to your needs. Book an appointment today.">
  <meta name="keywords" content="Medical, Clinic, Health, Enrich">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400;700&family=Poppins:wght@300;600;700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>

<body class="index-page">

  <!-- Header Section -->
  <header id="header" class="header sticky-top">

    <div class="topbar d-flex align-items-center">
      <div class="container d-flex justify-content-between">
        <div class="contact-info d-flex align-items-center">
          <i class="bi bi-phone ms-4"><span>+965 22220359</span></i>
          <i class="bi bi-phone ms-4"><span>+965 65557393</span></i>
        </div>
        <div class="social-links d-flex align-items-center">
          <a href="#" class="snapchat" target="_blank"><i class="bi bi-snapchat"></i></a>
          <a href="https://www.facebook.com" class="facebook" target="_blank"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com" class="instagram" target="_blank"><i class="bi bi-instagram"></i></a>
          <a href="https://www.tiktok.com" class="tiktok" target="_blank"><i class="bi bi-tiktok"></i></a>
        </div>
      </div>
    </div>
    <div class="branding d-flex align-items-center">

<div class="container position-relative d-flex align-items-center justify-content-between">
  <a href="index.html" class="logo d-flex align-items-center me-auto">
    <!-- Uncomment the line below if you also wish to use an image logo -->
    <!-- <img src="assets/img/logo.png" alt=""> -->
     <img src="logo.png" width="130 px" height="550" >
     <h1 class="sitename" style="font-family: 'Dancing Script', cursive;">Enrich</h1>
     
  </a>
    <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index.php" class="active">Home<br></a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
           
            <li><a href="#doctors">Doctors</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="login.php">Login</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
        
        <a class="cta-btn d-none d-sm-block" href="#appointment">Make an Appointment</a>

      </div>

    </div>
    
  </header>

  <!-- Form Sec"tion -->

  <section class="vh-100">
  <div class="container-fluid h-custom">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-md-9 col-lg-6 col-xl-5">
        <img src="logo.png"
          class="img-fluid" alt="Sample image">
      </div>
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">


        <form  onsubmit="return validation()" method="post" name="loginform" action="login_handler.php">


          <!-- Email input -->
          <div data-mdb-input-init class="form-outline mb-4">
          <label class="form-label" for="form3Example3">Email address</label>
            <input type="email" id="form3Example3" class="form-control form-control-lg"
              placeholder="Enter a valid email address" name="email" />
           
          </div>

          <!-- Password input -->
          <div data-mdb-input-init class="form-outline mb-3">
          <label class="form-label" for="form3Example4">Password</label>

            <input type="password" id="form3Example4" class="form-control form-control-lg"
              placeholder="Enter password" name="pwd" />
           
          </div>

          <div class="d-flex justify-content-between align-items-center">
            <!-- Checkbox -->
            <div class="form-check mb-0">
              <input class="form-check-input me-2" type="checkbox" value="" id="form2Example3" />
              <label class="form-check-label" for="form2Example3">
                Remember me
              </label>
            </div>
            <a href="#!" class="text-body">Forgot password?</a>
          </div>

          <div class="text-center text-lg-start mt-4 pt-2">
            <button   type="submit" data-mdb-button-init data-mdb-ripple-init class="text-center"
              style="padding-left: 2.5rem; padding-right: 2.5rem;  background-color:#C2A267; border-color:#C2A267;">Login</button>
            <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="signup.php"
                class="link-danger">Register</a></p>
          </div>

        </form>
      </div>
    </div>
  </div>
 

    <!-- Right -->
    <div>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-google"></i>
      </a>
      <a href="#!" class="text-white">
        <i class="fab fa-linkedin-in"></i>
      </a>
    </div>
    <!-- Right -->
  </div>
</section>





<footer id="footer" class="footer faq section beige">

<div class="container footer-top">
  <div class="row gy-4">
    <div class="col-lg-4 col-md-6 footer-about">
      <a href="index.html" class="logo d-flex align-items-center">
        <span class="sitename">Enrich Clinic</span>
      </a>
      <div class="footer-contact pt-3">
        <p>Al Khansa Street</p>
        <p>Salmiya 20003, Kuwait</p>
        <p class="mt-3"><strong>Phone:</strong><br><span>+ 965 22220359</span><br><span>+ 965 65557393</span></p>
        <p><strong>Email:</strong> <span>info@drhossamclinic.com</span></p>
      </div>
      <div class="social-links d-flex mt-4">
        <a href=""><i class="bi bi-snapchat"></i></a>
        <a href="https://www.facebook.com/share/1DNVy7dBc7/?mibextid=JRoKGi"><i class="bi bi-facebook"></i></a>
        <a href="https://www.instagram.com/drhossam.hamdy.clinic/profilecard/?igsh=ZDltY3Y4cW1ic2Fn"><i class="bi bi-instagram"></i></a>
        <a href="https://www.tiktok.com/@hossamhamdan218?_t=ZS-8rrPBmE7CjJ&_r=1"><i class="bi bi-tiktok"></i></a>
      </div>
    </div>

    <div class="col-lg-2 col-md-3 footer-links">
      <h4>Useful Links</h4>
      <ul>
        <li><a href="#hero">Home</a></li>
        <li><a href="#about">About us</a></li>
        <li><a href="#">Terms of service</a></li>
        <li><a href="#">Privacy policy</a></li>
      </ul>
    </div>

    <div class="col-lg-2 col-md-3 footer-links">
      <h4>Our Services</h4>
      <ul>
        <li><a href="#services">Services</a></li>
        <li><a href="#appointment">Book Your Appointment</a></li>
      
      </ul>
    </div>

    

  </div>
</div>

<div class="container copyright text-center mt-4">
  <p>© <span>Copyright</span> <strong class="px-1 sitename">Enrich</strong> <span>All Rights Reserved</span></p>
  
</div>

</footer>
  


</html>
